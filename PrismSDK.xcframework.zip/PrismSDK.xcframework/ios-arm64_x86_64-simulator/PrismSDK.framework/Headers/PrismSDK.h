//
//  PrismSDK.h
//  PrismSDK
//
//  Created by Ahmed Abdelkhalek on 08.12.23.
//

#import <Foundation/Foundation.h>

//! Project version number for PrismSDK.
FOUNDATION_EXPORT double PrismSDKVersionNumber;

//! Project version string for PrismSDK.
FOUNDATION_EXPORT const unsigned char PrismSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PrismSDK/PublicHeader.h>


