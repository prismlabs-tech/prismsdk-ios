//
//  PrismKit.h
//  PrismKit
//
//  Created by Anthony Castelli on 4/14/23.
//

#import <Foundation/Foundation.h>

//! Project version number for PrismKit.
FOUNDATION_EXPORT double PrismKitVersionNumber;

//! Project version string for PrismKit.
FOUNDATION_EXPORT const unsigned char PrismKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PrismKit/PublicHeader.h>


